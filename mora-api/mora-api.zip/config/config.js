const config = {
    database:'game_mora',
    user: 'root',
    pwd: 'root',
    host: 'localhost',
    dialect: 'mysql',
    port: '3306',
    unionApi:'http://192.168.8.115/',
    serverIp:'192.168.1.238',
    serverPort:'666',
};
module.exports = config;