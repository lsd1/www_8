class getError{


}